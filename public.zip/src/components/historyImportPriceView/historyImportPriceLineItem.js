

function HistoryImportPriceLineItem(){

}

export default HistoryImportPriceLineItem;