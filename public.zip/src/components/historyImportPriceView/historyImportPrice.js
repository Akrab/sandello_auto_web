
function getHistorParseData() {
    return axios.get('/api/v1/historyPriceParse');
}



function HistoryImportPrice() {
    return (<div>Holo</div>)
}

export default HistoryImportPrice;